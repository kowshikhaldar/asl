
<!DOCTYPE html>
<html>
	<head>
		<title>Aiub Library</title>
		<link rel="icon" type="./image/x-icon" href="../images/aiub-logo.svg">
		<link rel="stylesheet" href="../css/Buttons.css">
	</head>
	
	<div class="x">
	<body>
		<center>
		<a href="https://www.aiub.edu/"><img src="../images/aiub-logo.svg" alt="aiub-logo"></a>
		<h1>Welcome</h1>
		<?php
		include ("../controll/process.php");
		?>
        <h2>Home</h2>	
		<div class="btn_success">
			<table  width ="1000px" >
				<tr>
				<th><a href="profile.php">Profile</a></th>
				<th><a href="sss.php">Special Sub Support</a></th>
				<th><a href="book.php">Read Book</a></th>
				<th><a href="cas.php">Check About Students</a></th>
				<th><a href="home.php">Home</a></th>
				<th><a href="login.php">Sign Out</a></th>

				</tr>
				

			
			</table></div><br><br>

			<table width="500px"  border="2px">
				<tr>
				<th>Student Name</th>
				<th>Id</th>
				<th>Request</th>

				</tr>
				<tr>
					<td>Student 01</td>
					<td>20-54601-1</td>
					<td>For Book</td>

				</tr>
				<tr>
					<td>Student 02</td>
					<td>20-54601-2</td>
					<td>For Book</td>

				</tr>
				<tr>
					<td>Student 03</td>
					<td>20-54601-3</td>
					<td>For Book</td>

				</tr>
				<tr>
					<td>Student 04</td>
					<td>20-54601-4</td>
					<td>For Book</td>

				</tr>
				<tr>
					<td>Student 05</td>
					<td>20-54601-5</td>
					<td>For Book</td>

				</tr>
				<tr>
					<td>Student 06</td>
					<td>20-54601-6</td>
					<td>For Book</td>

				</tr>
				<tr>
					<td>Student 07</td>
					<td>20-54601-7</td>
					<td>For Book</td>

				</tr>
				<tr>
					<td>Student 08</td>
					<td>20-54601-8</td>
					<td>For Book</td>

				</tr>

				
				
			</table>
			
			

		</center>
		
		
		
		
	</body>
</div>
</html>