
<?php
include("../Controller/Reg_process.php"); ?>

<!DOCTYPE html>
<html>
<head>
    <title>Registration</title>
   
</head>
<body>
    
    <h1 align="center">Registration Form</h1>
    <Form action="" method ="POST">
    <table align="center">

        <tr>
            <td>
                <fieldset>
                    <legend>
                         <h2>Registration Information</h2>
</legend>
<table>
        <tr>
            <td>First Name:</td>
            <td><input type="text" name="fname"></td>
        </tr>
        <tr>
            <td>Last Name:</td>
            <td><input type="text" name="lname"></td>
        </tr>
        <tr>
            <td>Email:</td>
            <td><input type="text" name="email"></td>
        </tr>
        <tr>
            <td>Address:</td>
            <td><input type="text" name="address"></td>
        </tr>
        <tr>
            <td>Date of Birth:</td>
            <td><input type="date" name="dob"></td>
        </tr>
        
        <tr>
            <td>Gender:</td>
            <td><input type="radio" value="Male" name="gender"> Male</td>
            <td><input type="radio" value="Female" name="gender"> Female</td>
            <td><input type="radio" value="Custom" name="gender">Custom</td>
        </tr>
        <tr>
            <td>Experience:</td>
            <td><input type="text" name="experience"></td>
        </tr>
        <tr>
            <td>Educational Background:</td>
            <td><input type="text" name="eduback "></td>
        </tr>
        <tr>
            <td>User Name:</td>
            <td><input type="text" name="uname"></td>
        </tr>
        <tr>
            <td>Create New Pass:</td>
            <td><input type="password" name="npass"></td>
        </tr>
        <tr>
            <td>Confirm Password:</td>
            <td><input type="password" name="cpass"></td>
        </tr>
        <tr>
            <td>Phone Number:</td>
            <td><input type="text" name="phone"></td>
        </tr>
        <tr>                        
            <td></td>
            <td><input type="submit" value="Submit" name="Submit">
            </td>
            </tr> <tr><td></td><td><input type="Reset" value="Reset" name="Reset"></td></tr>
</table>
        
</Form>
</body>
</html>