<?php
session_start(); 
$fnameerror = $lnameerror = $emailerror = $addresserror = $doberror = $gendererror = $experror = $edubackerror =$usernameerror= $cnpasserror=$passerror= $pnoerror ="";
$fname = $lname = $email= $address= $dob = $gender= $experience= $eduback= $uname = $npass = $cpass ="";

if($_SERVER["REQUEST_METHOD"] == "POST")
{
    if(empty($_POST["fname"]))
    {
        $fnameerror="Required";
    }
    else
    {
        $fname= test_input($_POST["fname"]);
    }

    if(empty($_POST["lname"]))
    {
        $lnameerror="Required";
    }
    else
    {
        $lname= test_input($_POST["lname"]);
    }
    if(empty($_POST["email"]))
    {
        $emailerror="Required";
    }
    else
    {
        $email= test_input($_POST["email"]);
    }
    if(empty($_POST["address"]))
    {
        $addresserror="Required";
    }
    else
    {
        $address= test_input($_POST["address"]);
    }
    if(empty($_POST["dob"]))
    {
        $doberror="Required";
    }
    else
    {
        $dob= test_input($_POST["dob"]);
    }
    if(empty($_POST["gender"]))
    {
        $gendererror="Required";
    }
    else
    {
        $gender= test_input($_POST["gender"]);
    }
    if(empty($_POST["experience"]))
    {
        $experror="Required";
    }
    else
    {
        $experience= test_input($_POST["experience"]);
    }
    if(empty($_POST["eduback"]))
    {
        $edubackerror="Required";
    }
    else
    {
        $eduback= test_input($_POST["eduback"]);
    }
    if(empty($_POST["uname"]))
    {
        $usernameerror="Required";
    }
    else
    {
        $uname= test_input($_POST["uname"]);
    }
    if(empty($_POST["npass"]))
    {
        $cnpasserror="Required";
    }
    else
    {
        $npass= test_input($_POST["npass"]);
    }
    if(empty($_POST["cpass"]))
    {
        $passerror="Required";
    }
    else
    {
        $npass= test_input($_POST["cpass"]);
    }
}













?>

