<?php

session_start();

$cookemail="";

if (isset($_SESSION["user"])) 
{
    header("Location: ../view/home.php");

}else
{
    
    if(isset($_COOKIE['email']))
    {
       $cookemail=$_COOKIE['email'];
    }

}

if (isset($_REQUEST["sbmt"])) {
    
    if (!empty($_REQUEST["username"] && !empty("pass"))) {
        $getjson = file_get_contents("../data/json/teacher.json");
        $decodedjson = json_decode($getjson, true);
   
        foreach ($decodedjson as $data) {
            if ($data["email"] == $_REQUEST["email"] && $data["pass"] == $_REQUEST["pass"]) {
                $_SESSION["user"] = $data;
                if(isset($_REQUEST["remem"]))
                {

                    setcookie("email", $_SESSION["email"]["email"], time() + 30*30*24*30,"../view/login.php");
                }
               
               header("Location: ../view/home.php");

                break;

            }else{
                $login_flag="User Not Found!";
            }
           

        }
    } else {
       $login_flag = "field can not be blanked";

    }



}


?>