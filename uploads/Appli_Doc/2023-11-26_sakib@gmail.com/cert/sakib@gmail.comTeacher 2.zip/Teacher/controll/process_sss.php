<?php
    function pp($name)
    {
        for ($i=0;$i<1;$i++){
            echo"<b>Course Names:<b> $name <br>";
        }
    }
    
    

?>