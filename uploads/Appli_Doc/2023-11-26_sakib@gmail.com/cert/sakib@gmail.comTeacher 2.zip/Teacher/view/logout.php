<?php

session_start() ;
session_destroy();
?>

<!DOCTYPE html>
<html lang="en">
<head>
   
    <title>Log Out Successfully</title>
</head>
<body>
<h2>Log Out Successfully</h2>
    
</body>
</html>


<?php
include("../controll/session_handle.php");

?>