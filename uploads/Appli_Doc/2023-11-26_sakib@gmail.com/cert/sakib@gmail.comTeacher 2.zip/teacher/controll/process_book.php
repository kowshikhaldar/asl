<?php
function kk($name)
{
    for ($i=0;$i<1;$i++){
        echo"Book Name: $name <br>";
    }
}
?>