<?php
function calculateTimeDifference($timestamp) 
{
	date_default_timezone_set('Asia/Dhaka');
    // Convert the timestamp to a DateTime object
    $postDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $timestamp);

    // Get the current DateTime
    $currentDateTime = new DateTime();

    // Calculate the time difference
    $timeDifference = $currentDateTime->diff($postDateTime);

    // Format and display the time difference
    echo "Posted ";
    if ($timeDifference->y > 0) {
        echo $timeDifference->y . " year" . ($timeDifference->y > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->m > 0) {
        echo $timeDifference->m . " month" . ($timeDifference->m > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->d > 0) {
        echo $timeDifference->d . " day" . ($timeDifference->d > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->h > 0) {
        echo $timeDifference->h . " hour" . ($timeDifference->h > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->i > 0) {
        echo $timeDifference->i . " minute" . ($timeDifference->i > 1 ? "s" : "") . " ago";
    } else {
        echo "a few seconds ago";
    }
}
	function showPost($a_no)
	{
		$servername="localhost";
		$uname="root";
		$pass="";
		$dbase="eduassist";
		$conn=new mysqli($servername,$uname,$pass,$dbase);
		if (!$conn)
        { 
            die('Connection FAILED! Error found: '.mysqli_error()); 
        }
		$sql="select * from eapost where a_no='$a_no'";
		$execute=mysqli_query($conn,$sql);

		if($execute->num_rows>0)
        {
        	while($q=mysqli_fetch_assoc($execute))
            {	?>
            <table>
            <tr>
               	<td><button type="submit" name="puser" class="user"><?php echo $q['user'];?></button></td>
                <td class="time"><?php calculateTimeDifference($q['date']);?></td>
            </tr>
            <tr>
              	<td colspan="2"><?php echo $q['article'];?></td>
            </tr>	<?php
            	if(!empty($q['file'])) 
            	{ ?>
            	<tr>
                	<td><?php echo $q['file'];?></td>
                	<td><button type="submit" name="download">Download</button></td>
            	</tr>	<?php                
                	if(isset($_POST['download']))
               		{
                    	header('Content-Type: application/octet-stream');
                    	header('Content-Disposition: attachment; filename="' . $q['file'] . '"');
                	}
            	}	?>
            	</table>	<?php
        	}
		}
		else
		{
			echo "<center>No Post Available...</center>";
		}
	}
?>

<!DOCTYPE html>
<html>
<head>
	<title>View Post</title>
	<link rel="stylesheet" href="EAstyles.css">
</head>
<body>
	<form method="post">
      <button type="submit" name="home" class="homebutton">EDUCATION<br>ASSISTANT</button><br>
      <fieldset>
      	<legend class="focus">Post Details</legend>
<?php
include 'EA.php';

	session_start();
	if(!isset($_SESSION['a_no'])) 
    {
    	header('Location:EAstuindex.php');
    }
    else
    {
    	$a_no=$_SESSION['a_no'];
        $cuser=$_SESSION['username'];
       	if(isset($_POST['backindex']))
        {
            header('Location:EAstuindex.php');
        }
        elseif(isset($_POST['backprofile']))
        {
            header('Location:EAprofile.php');
        }
        elseif(isset($_POST['profile']))
        {
            if($_POST['profile']==$cuser)
            {
                header('Location:EAprofile.php');
            }
            else
            {
                header('Location:EAview.php');
            }
        }
        elseif(isset($_POST['com']))
        {
            $comment=new EAcomment($_POST['comment']);
            $comment->insertComment($a_no,$cuser);
            $_POST['comment']='';
            header('Location:EAposts.php');
        }
        else
        {
            showPost($a_no);
            $servername="localhost";
			$uname="root";
			$pass="";
			$dbase="eduassist";
			$conn=new mysqli($servername,$uname,$pass,$dbase);
			if (!$conn)
        	{ 
            	die('Connection FAILED! Error found: '.mysqli_error()); 
        	}
			$sql="select * from eacomment where a_no='$a_no'";
			$execute=mysqli_query($conn,$sql);
			if($execute->num_rows>0)
			{	?> 
				<hr><hr>
				Comments:	<?php
				while($q=mysqli_fetch_assoc($execute))
    			{	?>
    			<table>
                <tr>
        			<td rowspan="2"><button type="submit" name="profile" class="user"><?php echo $q['cuser'];?></button></td> 
        		</tr>
        		<tr>
       				<td rowspan="2"  class="limited_text"><?php echo $q['comment'];?></td>
       				<td class="time"><?php calculateTimeDifference($q['cdate']); ?></td> 
       			</tr>
       			<tr>
       			</table>	<?php
       			}	?>
            	<hr>
            	<table>
    			<tr>
            	<td colspan="2">Write a Comment:</td>
                </tr>
        	    <tr>
            		<td rowspan="2"><textarea name="comment" class="intext" cols="30" rows="2"></textarea></td>
            		<td><button type="submit" name="com" class="small">DONE</button></td>
            	</tr>
            	</table>	<?php
        	}
            else
            { ?>
            <table>
            <hr><hr>
            <tr>
                <td>Write NEW Comment:</td>
            </tr>
        	<tr>
            	<td rowspan="2"><textarea name="comment" class="intext" cols="30" rows="2"></textarea></td>
            	<td><button type="submit" name="com" class="small">DONE</button></td>
            </tr>
			</table> <?php
            }
        }
    }
?>
      </fieldset>
      <button type="submit" name="backindex" class="place">BACK(index)</button>
      <button type="submit" name="backprofile" class="place">BACK(profile)</button>
  	</form>
</body>
</html>
