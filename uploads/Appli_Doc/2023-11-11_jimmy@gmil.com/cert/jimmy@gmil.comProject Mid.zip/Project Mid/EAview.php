<?php
  session_start();
  $suser=$_SESSION['suser'];
  $username=$_SESSION['username'];

  $servername="localhost";
  $user="root";
  $pass="";
  $dbase="eduassist";
  $conn=new mysqli($servername,$user,$pass,$dbase);
  if (!$conn)
  { 
    die('Connection FAILED! Error found: '.mysqli_error()); 
  }
?>

<!DOCTYPE html>
<html>
<head>
  <title>Profile:</title>
  <link rel="stylesheet" href="EAstyles.css">
</head>
<body>
  <form method="post">
    <button type="submit" name="home" class="homebutton">EDUCATION<br>ASSISTANT</button><br>
    <options_left>    
      <hr><hr>
      <center><button type="submit" name="logout" class="logout">SIGN out</button></center>
    </options_left>
    <options_right>
      <center><button type="submit" name="goback">Go Back</button></center>
    </options_right>
        <?php
        if(!isset($_SESSION['suser'])) 
        {
          header('Location:EAstuindex.php');
        }
        elseif(isset($_POST['goback']))
        {
          header('Location:EAstuindex.php');
        }
        elseif(isset($_POST['logout']))
        {
          header('Location:EAlogin.php');
        }
        elseif(isset($_POST['viewpublications'])) 
        {
          $sql3="select * from eapost where user='$suser'";
          $execute3=$conn->query($sql3);
          if($execute3->num_rows>0)
          {
            while($q3=mysqli_fetch_assoc($execute3))
            {
              if($q3['status']!=0)
              { ?>
                <p class="limited_text"><?php echo $q3['article']; ?></p><br>
                <?php echo $q3['file']; ?>
                <button type="submit" name="down" class="small">Download</button> <?php
                if(isset($_POST['download']))
                {
                  header('Content-Type: application/octet-stream');
                  header('Content-Disposition: attachment; filename="' . $q['file'] . '"');
                }
              }
            }
          }
          else
          {
            echo "<center><warning>No publications found!</warning></center>";
          }
        }
        elseif(isset($_POST['creq']))
        {
          $sql4="insert into connectionreq (sendby, sendto) values ('$username', '$suser')";
          $execute4=$conn->query($sql4);
          if($execute4)
          {
            echo "<center><warning>Connection request sent successfully!</warning></center>";
          }
          else
          {
            echo "<center><warning>Connection request failed!</warning></center>";
          }
        }
        else
        {
          $sql="select usertype from logininfo where username='$suser'";
          $execute=$conn->query($sql);
          $usertype=mysqli_fetch_assoc($execute);
          $ut=$usertype['usertype'];  ?>
          <div class="sticky">
            <center><button type="submit" name="sprofile" class="focus"><?Php  echo $ut," profile:<br>"; ?></button></center>
          </div>
          <div class="feed">  <?php
          $sql2="select * from $ut where username='$suser'";
          $execute2=$conn->query($sql2);
          while($q2=mysqli_fetch_assoc($execute2))
          {
            echo "Name: ",$q2['name'];
            echo "<br>Email: ",$q2['email'];
            echo "<br>Phone: ",$q2['phone'];
            echo "<br>department: ",$q2['department'];
          } ?>
          <hr><button type="submit" name="viewpublications" class="focus">View Publications</button>
          <shift-right><button type="submit" name="creq" class="focus">Send Connection Request</button></shift-right>  <?php
        } ?>
      </div>
    </form>
  </body>
  </html>