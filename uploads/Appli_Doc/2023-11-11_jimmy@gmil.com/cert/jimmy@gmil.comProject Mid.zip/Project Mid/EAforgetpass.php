<!DOCTYPE html>
<html>
<head>
	<title>Forgot Password</title>
	<link rel="stylesheet" href="EAstyles.css">
</head>
<body>
	<form method="post">
		<button type="submit" name="home" class="homebutton">EDUCATION<br>ASSISTANT</button><br>
			<center>
			<fieldset>
			<legend><h2>RETRIVE ACCOUNT</h2></legend>
			<h3>Provide Information:</h3>
			<table border="0">
				<tr>
					<td>Username:</td>
					<td><input type="text" name="uname"></td>
				</tr>
				<tr>
					<td>Email:</td>
					<td><input type="Email" name="uemail"></td>
				</tr>
				<tr>
					<td colspan="2"><center><button type="submit" name="retrive" class="retrive">REQUEST PASSWORD!</button></center></td>
				</tr>
			</table>
			<?php
			include 'EAusers.php';
			if(isset($_POST['retrive']))
			{
				$username=$_POST['uname'];
				$email=$_POST['uemail'];
				$user=new User($username,$email);
				$user->retrivePassword($username,$email);
			}
			elseif(isset($_POST['home']))
			{
				header("Location:EAhome.php");
			}
			elseif(isset($_POST['exit']))
			{
				session_destroy();
				header("Location:EAlogin.php");
			}
			else
			{
				echo "<center><note>**This is a trail run on this platfrom**<br>***©AIUB::WebTechnologies::Section[B]::Group5- All Right Researved***</note></center>";
			}
			?>
			</fieldset>
			<button type="submit" name="exit">BACK</button>
		</form>	
	</center>
</body>
</html>