<?php
function userValidate($username)
{
	$servername="localhost";
	$user="root";
	$pass="";
	$dbase="eduassist";
	$conn=new mysqli($servername,$user,$pass,$dbase);
	$sql="select username from logininfo";
		
	if(!$conn)
	{ 
		die('Connection FAILED! Error found: '.mysqli_error()); 
	}
	$exicute=$conn->query($sql);
		
	while($q=mysqli_fetch_assoc($exicute))
	{
		if($username==$q["username"])
		{
			return false;
		}
		else
		{
			return true;
		}
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Teacher Registration</title>
	<link rel="stylesheet" href="EAstyles.css">
</head>
<body>
	<form method="post">
	<button type="submit" name="home" class="homebutton">EDUCATION<br>ASSISTANT</button><br>
		<center>
		<h4 class="focus">Registration: Teacher</h4>
		<input type="hidden" value="teacher" name="usertype">			
			<table border="0">
				<tr>
					<td>Name:</td>
					<td><input type="text" name="name" class="intext"></td>
				</tr>	
				<tr>
					<td>Age:</td>
					<td><input type="number" name="age" class="intext"></td>
				</tr>
				<tr>
					<td>Email:</td>
					<td><input type="email" name="email" class="intext"></td>
				</tr>
				<tr>
					<td>Phone:</td>
					<td><input type="text" name="phone" class="intext"></td>
				</tr>
				<tr>
					<td>Workplace:</td>
					<td><input type="text" name="workplace" class="intext"></td>
				</tr>
				<tr>
					<td>Designation:</td>
					<td><input type="text" name="designation" class="intext"></td>
				</tr>
				<tr>
					<td>Faculty:</td>
					<td><input type="text" name="faculty" class="intext"></td>
				</tr>
				<tr>
					<td>Department:</td>
					<td><input type="text" name="department" class="intext"></td>
				</tr>
				<tr>
					<td>Address:</td>
					<td><input type="text" name="address" class="intext"></td>
				</tr>
				<tr>
					<td>Username:</td>
					<td><input type="text" name="uname" class="intext"></td>
				</tr>
				<tr>
					<td>Password:</td>
					<td><input type="Password" name="pass"></td>
				</tr>
				<tr>
					<td>Confirm:</td>
					<td><input type="Password" name="cpass"></td>
				<tr>
					<td colspan="2"><center><button type="submit" name="treg">SUBMIT</button></center></td>
				</tr>
			</table>
		</center>
	</form>
</body>
</html>
<?php
include 'EAteachers.php';
include 'EAusers.php';

	if(!empty($_POST['name'])&&!empty($_POST['age'])&&!empty($_POST['email'])&&!empty($_POST['phone'])&&!empty($_POST['workplace'])&&!empty($_POST['designation'])&&!empty($_POST['faculty'])&&!empty($_POST['department'])&&!empty($_POST['address'])&&!empty($_POST['uname'])&&!empty($_POST['pass'])&&!empty($_POST['cpass']))
	{
		if(userValidate($_POST['uname'])==true)
		{
			if(isset($_POST['treg']))
			{
				$user=new User($_POST['uname'],$_POST['pass']);
				$teacher=new Teacher($_POST['name'],$_POST['age'],$_POST['email'],$_POST['phone'],$_POST['workplace'],$_POST['designation'],$_POST['faculty'],$_POST['department'],$_POST['address'],$_POST['uname']);
				$user->insertUser($_POST['usertype']);
				$teacher->registerTeacher();
				echo "<center>Successfully Registered!</center>";
				echo "<center><aside>Click <a href=","EAlogin.php",">HERE</a> to LOGIN....<aside></center>";
			}
			else
			{
				echo "<center><aside>Something went wrong! Try again...</aside></center>";
			}
		}
		else
		{
			echo "<center><aside>USERNAME taken!<br>Choose another one...</aside></center>";
		}
	}
	elseif(isset($_POST['home']))
	{
		header("Location:EAhome.php");
	}
	elseif (!empty($_POST['pass'])&&empty($_POST['cpass']))
	{
		if(isset($_POST['pass'])==isset($_POST['cpass']))
		{
			echo "<center><aside>Password MATCHED...</aside></center>";
		}
		else
		{
			echo "<center><aside>Password did NOT MATCH!</aside></center>";
		}
	}
	else
	{
		echo "<center><aside>***Please Fill all the FIELDS then SUBMIT***</aside></center>";
	}
?>