<!DOCTYPE html>
<html>
<head>
	<title>LOGIN</title>
	<link rel="stylesheet" href="EAstyles.css">
</head>
<body>
	<form method="post">
		<button type="submit" name="home" class="homebutton">EDUCATION<br>ASSISTANT</button><br>
		<center>
			<fieldset>
			<legend><h2>USER LOGIN</h2></legend>
			<h3>Provide Your Username and Password:</h3>
			<table border="0">
				<tr>
					<td>Username:</td>
					<td><input type="text" name="username" class="intext"></td>
					</tr>
					<tr>
						<td>Password:</td>
						<td><input type="Password" name="password" class="intext"></td>
					</tr>
					<tr>
						<td colspan="2"><center><button type="submit" name="login" class="login">LOGIN</button></center></td>
						<td><button type="submit" name="recover" class="retrive">Forgot PASSWORD?</button></td>
					</tr>
				</table>
				Yet Not Registered?
				<button type="submit" name="reg">Click HERE to REGISTER!</button>
			</fieldset>
		</center>
	</form>
</body>
</html>

<?php
include 'EAusers.php';

	if(isset($_POST['login']))
	{
		$user=new User($_POST['username'],$_POST['password']);
		$user->loginValidation();
	}
	elseif(isset($_POST['reg']))
	{
		header("Location:EAregister.php");
	}
	elseif(isset($_POST['home']))
	{
		header("Location:EAhome.php");
	}
	elseif(isset($_POST['recover']))
	{
		header("Location:EAforgetpass.php");
	}
	else
	{
		echo "<center><note>**This is a trail run on this platfrom**<br>***©AIUB::WebTechnologies::Section[B]::Group5- All Right Researved***</note></center>";
	}
?>