<?php
	class Teacher
	{
		public $name;
		public $age;
		public $email;
		public $phone;
		public $institute;
		public $designation;
		public $faculty;
		public $department;
		public $address;
		public $username;

		public function __construct($name,$age,$email,$phone,$workplace,$designation,$faculty,$department,$address,$username)
		{
			$this->name=$name;
			$this->age=$age;
			$this->email=$email;
			$this->phone=$phone;
			$this->institute=$institute;
			$this->designation=$designation;
			$this->faculty=$faculty;
			$this->department=$department;
			$this->address=$address;
			$this->username=$username;
		}

		public function registerTeacher()
		{
			$servername="localhost";
			$user="root";
			$pass="";
			$dbase="eduassist";
			$conn=new mysqli($servername,$user,$pass,$dbase);
			$sql="insert into teacher (name, age, email, phone, institute, designation, faculty, department, address, username) values ('$this->name' , '$this->age' , '$this->email' , '$this->phone' , '$this->institute' , '$this->designation' , '$this->faculty' , '$this->department' , '$this->address' , '$this->username')";
			$exicute=mysqli_query($conn,$sql);
		}
	}
?>