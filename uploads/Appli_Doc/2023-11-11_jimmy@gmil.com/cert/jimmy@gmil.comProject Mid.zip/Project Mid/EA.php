<?php
class EApost
{
	public $user;
	public $status;
	public $article;
	public $file;

	public function __construct($status,$article,$file)
	{
		$this->status=$status;
		$this->article=$article;
		$this->file=$file;
	}

	public function insertPost($user)
	{
		$servername="localhost";
		$uname="root";
		$pass="";
		$dbase="eduassist";
		$conn=new mysqli($servername,$uname,$pass,$dbase);
		if (!$conn)
        { 
            die('Connection FAILED! Error found: '.mysqli_error()); 
        }
		$sql="insert into eapost (user,status,article,file) values ('$user','$this->status','$this->article','$this->file')";
		$execute=mysqli_query($conn,$sql);
	}

	public function updatePost($article,$file,$a_no)
	{
		$servername="localhost";
		$uname="root";
		$pass="";
		$dbase="eduassist";
		$conn=new mysqli($servername,$uname,$pass,$dbase);
		if (!$conn)
        { 
            die('Connection FAILED! Error found: '.mysqli_error()); 
        }
		$sql="update eapost article='$article',file='$file'' where a_no='$a_no'";
		$execute=mysqli_query($conn,$sql);
	}

	public function deletePost($a_no)
	{
		$servername="localhost";
		$uname="root";
		$pass="";
		$dbase="eduassist";
		$conn=new mysqli($servername,$uname,$pass,$dbase);
		if (!$conn)
        { 
            die('Connection FAILED! Error found: '.mysqli_error()); 
        }
		$sql="delete from eapost where a_no='$a_no'";
		$execute=mysqli_query($conn,$sql);
	}
}

class EAcomment
{
	public $comment;

	public function __construct($comment)
	{
		$this->comment=$comment;
	}

	public function insertComment($a_no,$cuser)
	{
		$servername="localhost";
		$uname="root";
		$pass="";
		$dbase="eduassist";
		$conn=new mysqli($servername,$uname,$pass,$dbase);
		if (!$conn)
        { 
            die('Connection FAILED! Error found: '.mysqli_error()); 
        }
		$sql="insert into eacomment (a_no,comment,cuser) values ('$a_no','$this->comment','$cuser')";
		$execute=mysqli_query($conn,$sql);
	}

	public function updateComment($a_no,$comment,$c_no)
	{
		$servername="localhost";
		$uname="root";
		$pass="";
		$dbase="eduassist";
		$conn=new mysqli($servername,$uname,$pass,$dbase);
		if (!$conn)
        { 
            die('Connection FAILED! Error found: '.mysqli_error()); 
        }
		$sql="update eacomment comment='$comment' where a_no='$a_no' and c_no='$c_no'";
		$execute=mysqli_query($conn,$sql);
	}

	public function deleteComment($a_no,$c_no)
	{
		$servername="localhost";
		$uname="root";
		$pass="";
		$dbase="eduassist";
		$conn=new mysqli($servername,$uname,$pass,$dbase);
		if (!$conn)
        { 
            die('Connection FAILED! Error found: '.mysqli_error()); 
        }
		$sql="delete from eacomment where a_no='$a_no' and c_no='$c_no'";
		$execute=mysqli_query($conn,$sql);
	}
}
?>