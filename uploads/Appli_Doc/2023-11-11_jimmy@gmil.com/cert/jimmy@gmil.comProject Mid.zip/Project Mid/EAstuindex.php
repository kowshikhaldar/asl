<?php
include 'EAusers.php';
include 'EAstudents.php';
include 'EAteachers.php';
include 'EA.php';

function calculateTimeDifference($timestamp) 
{
    date_default_timezone_set('Asia/Dhaka');
    // Convert the timestamp to a DateTime object
    $postDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $timestamp);

    // Get the current DateTime
    $currentDateTime = new DateTime();

    // Calculate the time difference
    $timeDifference = $currentDateTime->diff($postDateTime);

    // Format and display the time difference
    echo "Posted ";
    if ($timeDifference->y > 0) {
        echo $timeDifference->y . " year" . ($timeDifference->y > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->m > 0) {
        echo $timeDifference->m . " month" . ($timeDifference->m > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->d > 0) {
        echo $timeDifference->d . " day" . ($timeDifference->d > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->h > 0) {
        echo $timeDifference->h . " hour" . ($timeDifference->h > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->i > 0) {
        echo $timeDifference->i . " minute" . ($timeDifference->i > 1 ? "s" : "") . " ago";
    } else {
        echo "a few seconds ago";
    }
}
function showPublication()
{
  $servername="localhost";
  $user="root";
  $pass="";
  $dbase="eduassist";
  $conn=new mysqli($servername,$user,$pass,$dbase);
  if (!$conn)
  { 
    die('Connection FAILED! Error found: '.mysqli_error()); 
  }
  else
  {
    $sqlpub="select * from eapost where status='1' order by date desc";
    $executepub=$conn->query($sqlpub);
    if($executepub->num_rows>0)
    {
      while($p=mysqli_fetch_assoc($executepub))
      { ?>
        <table>
          <tr>
            <th>Name</th>
            <th>Article</th>
            <th>Date</th>
          </tr>
          <tr>
            <td><button type="submit" name="puser" class="user"><?php echo $p['user'];  ?></button></td>
            <td class="limited_text"><?php echo $p['article'];?></td>
            <td class="time"><?php calculateTimeDifference($p['date']);?></td>
          </tr> <?php
          if(!empty($q['file']))
          { ?>
          <tr>
            <td><?php echo $q['file'];?></td>
            <td><button type="submit" name="download" class="small">Download</button></td>
          </tr>
          </table>
          <center><button type="submit" name="writecom">View Article</button></center><hr> <?php
            if(isset($_POST['download']))
            {
              header('Content-Type: application/octet-stream');
              header('Content-Disposition: attachment; filename="' . $q['file'] . '"');
            }
          }
        }
      }
      else
      {
        echo "<center>No Updates Available...</center>";
      }
    }
  }

session_start();
$cuser=$_SESSION['username'];
$table=$_SESSION['usertype'];
?>

<!DOCTYPE html>
<head>
  <title>Index</title>
  <link rel="stylesheet" href="EAstyles.css">
</head>
<body>
  <form method="post">
    <button type="submit" name="home" class="homebutton">EDUCATION<br>ASSISTANT</button>
      <options_left>
        Write here to POST:<br>
        <input type="hidden" name="status" value="0">
        <textarea name="article" class="intext" cols="36" rows="6"></textarea><br>
        <input type="file" name="upfile" class="intext">
        <center><button type="submit" name="write">POST</button></center>
        <hr><hr><br>
        <?php 
        if($_SESSION['usertype']=="student")
        {
          echo "Do you know dear, ", $_SESSION['usertype'],"?<br><br>";
          echo "'Education’s purpose is to replace an empty mind with an open one.' <br> – Malcolm Forbes<br>";
        }
        if($_SESSION['usertype']=="teacher")
        {
          echo "Dear, ", $_SESSION['usertype'],",<br><br> Once a great philosopher, Maimonides, said-<br>'Give a man a fish and you feed him for a day; teach a man to catch a fish and you feed him for a lifetime.'<br>";
        }
        ?>  <hr><hr>
        <center><button type="submit" name="logout" class="logout">SIGN out</button></center>
      </options_left>
      <options_right>
        <button type="submit" name="publications" class="menu">Show Recent Publications</button> <?php
        if(isset($_POST['publications']))
        { ?>
          Recently Published:<hr> <?php
          showPublication();
        } ?>
      </options_right>
      <div class="sticky">
        <center><button type="submit" name="profile" class="focus">Welcome, Mr. <?php echo $_SESSION['username'];?></button></center>
      </div>
      <div class="feed">
      <?php
          if(!isset($_SESSION['username'])) 
          {
            header('Location:EAlogin.php');
          }
          else
          {
            if(isset($_POST['logout']))
            {
              session_destroy();
              header('Location:EAlogin.php');
            }
            elseif(isset($_POST['puser']))
            {
              if($_POST['puser']==$cuser)
              {
                header('Location:EAprofile.php');
              }
              else
              {
                $suser=$_POST['puser'];
                $_SESSION['suser']=$suser;
                header('Location:EAview.php');
              }
            }
            elseif(isset($_POST['profile']))
            {
              header('Location:EAprofile.php');
            }
            else
            {
              if(isset($_POST['write']))
              {
                if(!empty($_POST['article']))
                {
                  $post=new EApost($_POST['status'],$_POST['article'],$_POST['upfile']);
                  $post->insertPost($_SESSION['username']);
                  $_POST['article']='';
                  $_POST['upfile']='';
                  header('Location:EAstuindex.php');
                }
                else
                {
                echo "<feed>Write something to post!</feed>";
                }
              }
              elseif(isset($_POST['writecom']))
              {
                $a_no=$_POST['writecom'];
                $_SESSION['a_no']=$a_no;
                header('Location:EAposts.php');
              }
              else
              {
                $servername="localhost";
                $user="root";
                $pass="";
                $dbase="eduassist";
                $conn=new mysqli($servername,$user,$pass,$dbase);
                if (!$conn)
                { 
                  die('Connection FAILED! Error found: '.mysqli_error()); 
                }

                $sqlpost="select * from eapost where user in (select username from student where department = (select department from $table where username = '$cuser') union select username from teacher where department = (select department from $table where username = '$cuser'))order by date desc";
                $execute=$conn->query($sqlpost);

                if($execute->num_rows>0)
                {
                  while($q=mysqli_fetch_assoc($execute))
                  { ?>
                    <table>
                    <tr>
                     <td><button type="submit" name="puser" class="user" value="<?php echo $q['user'];?>"><?php echo $q['user'];?></button></td>
                      <td class="time"><?php calculateTimeDifference($q['date']);?></td>
                    </tr>
                    <tr>
                      <td class="limited_text"><?php echo $q['article'];?></td>
                    </tr>  <?php
                    if(!empty($q['file']))
                      { ?>
                    <tr>
                      <td><?php echo $q['file'];?></td>
                      <td><button type="submit" name="download" class="small">Download</button></td>
                    </tr> <?php
                      if(isset($_POST['download']))
                      {
                        header('Content-Type: application/octet-stream');
                        header('Content-Disposition: attachment; filename="' . $q['file'] . '"');
                      }
                    } ?>
                    <tr>
                      <td><button type="submit" name="writecom" value="<?php echo $q['a_no']; ?>">View Post</button></td>
                    </tr>
                    </table>
                    <hr>  <?php
                  }
                }
                else
                {
                  echo "<center>No Updates Available...</center>";
                }
              }
            }
          }
        ?>
      </div>
  </form>
</body>
</html>