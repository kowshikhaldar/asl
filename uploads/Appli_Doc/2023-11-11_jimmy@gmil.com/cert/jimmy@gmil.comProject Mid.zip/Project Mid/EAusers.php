<?php
class User
{
	public $username;
	public $password;

	public function __construct($username,$password)
	{
		$this->username=$username;
		$this->password=$password;
	}

	public function insertUser($usertype)
	{
		$servername="localhost";
		$uname="root";
		$pass="";
		$dbase="eduassist";
		$conn=new mysqli($servername,$uname,$pass,$dbase);
		$sql="insert into logininfo (username,password,usertype) values ('$this->username','$this->password','$usertype')";
		$exicute=mysqli_query($conn,$sql);
	}

	public function loginValidation()
	{
		session_start();
		$servername="localhost";
		$user="root";
		$pass="";
		$dbase="eduassist";
		$conn=new mysqli($servername,$user,$pass,$dbase);
		if (!$conn)
		{ 
			die('Connection FAILED! Error found: '.mysqli_error()); 
		}

		$sqlverify="select * from logininfo where username='$this->username' and password='$this->password'";
		$execute=$conn->query($sqlverify);
		
		if($execute->num_rows>0)
		{
			while($q=mysqli_fetch_assoc($execute))
			{	
				if($this->username==$q["username"]&&$this->password==$q["password"]&&$q["usertype"]=="student")
				{
					$_SESSION['username']=$q["username"];
					$_SESSION['usertype']=$q["usertype"];
					header("Location:EAstuindex.php"); 
				}
				elseif($this->username==$q["username"]&&$this->password==$q["password"]&&$q["usertype"]=="teacher")
				{
					$_SESSION['username']=$q["username"];
					$_SESSION['usertype']=$q["usertype"];
					header("Location:EAstuindex.php"); 
				}
				else
				{
					session_destroy();
				}
			}
		}
		else
		{
			echo "<center><warning>Invalid username or password!</warning></center>";
		}
	}

	public function retrivePassword($check_uname,$check_email)
	{
		session_start();
		$servername="localhost";
		$username="root";
		$password="";
		$dbase="eduassist";
		$conn=new mysqli($servername,$username,$password,$dbase);
		$sql="select * from logininfo where username='$check_uname'";
		if (!$conn)
		{ 
			die('Connection FAILED! Error found: '.mysqli_error()); 
		}

		$exicute=$conn->query($sql);
		
		while($q=mysqli_fetch_assoc($exicute))
		{
			if($check_uname==$q["username"]&&$q["usertype"]=="student")
			{
				$_SESSION['username']=$q["username"];
				$sql2= "select student.*, logininfo.* from student, logininfo where student.username='$check_uname' and logininfo.username='$check_uname'";
				$execute2=$conn->query($sql2);

				while($q2=mysqli_fetch_assoc($execute2))
				{
					if($check_uname==$q2['username']&&$check_email==$q2['email'])
					{
						echo "<hr><center>Your PASSWORD is: <success>", $q2['password'],"</success><center>";
						session_destroy();
					}
					else
					{
						echo "<hr><center><h3>Invalid USERNAME or EMAIL!</h3></center>";
						echo "<center><h4>Click <a href=","EAforgetpass.php",">HERE </a>to retry!</h4></center>";
						echo "<center><h4>Click <a href=","EAlogin.php",">HERE</a> to LOGIN....</h4></center>";
						session_destroy();
					}
				}
			}
			elseif($username==$q["username"]&&$q["usertype"]=="teacher")
			{
				$_SESSION['username']=$q["username"];
				$sql3= "select teacher.*, logininfo.* from teacher, logininfo where teacher.username='$check_uname' and logininfo.username='$check_uname'";
				$execute3=$conn->query($sql3);

				while($q3=mysqli_fetch_assoc($execute3))
				{
					if($check_uname==$q3['username']&&$check_email==$q3['email'])
					{
						echo "<hr><center>Your PASSWORD is: <success>", $q3['password'],"</success><center>";
						session_destroy();
					}
					else
					{
						echo "<hr><center><h3>Invalid USERNAME or EMAIL!</h3></center>";
						echo "<center><h4>Click <a href=","EAforgetpass.php",">HERE </a>to retry!</h4></center>";
						echo "<center><h4>Click <a href=","EAlogin.php",">HERE</a> to LOGIN....</h4></center>";
						session_destroy();
					}
				}
			}
			else
			{
				echo "<hr><center><h3>Invalid USERNAME or EMAIL!</h3></center>";
				echo "<center><h4>Click <a href=","EAforgetpass.php",">HERE </a>to retry!</h4></center>";
				echo "<center><h4>Click <a href=","EAlogin.php",">HERE</a> to LOGIN....</h4></center>";
				session_destroy();
			}
		}
	}
}
?>