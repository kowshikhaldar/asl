<?php
include 'EAusers.php';
include 'EAstudents.php';
include 'EAteachers.php';
include 'EA.php';

function calculateTimeDifference($timestamp) 
{
    date_default_timezone_set('Asia/Dhaka');
    // Convert the timestamp to a DateTime object
    $postDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $timestamp);

    // Get the current DateTime
    $currentDateTime = new DateTime();

    // Calculate the time difference
    $timeDifference = $currentDateTime->diff($postDateTime);

    // Format and display the time difference
    echo "Posted ";
    if ($timeDifference->y > 0) {
        echo $timeDifference->y . " year" . ($timeDifference->y > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->m > 0) {
        echo $timeDifference->m . " month" . ($timeDifference->m > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->d > 0) {
        echo $timeDifference->d . " day" . ($timeDifference->d > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->h > 0) {
        echo $timeDifference->h . " hour" . ($timeDifference->h > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->i > 0) {
        echo $timeDifference->i . " minute" . ($timeDifference->i > 1 ? "s" : "") . " ago";
    } else {
        echo "a few seconds ago";
    }
}

session_start();
$cuser=$_SESSION['username'];
$table=$_SESSION['usertype'];

$servername="localhost";
$user="root";
$pass="";
$dbase="eduassist";
$conn=new mysqli($servername,$user,$pass,$dbase);
if (!$conn)
{ 
  die('Connection FAILED! Error found: '.mysqli_error()); 
}

?>
<!DOCTYPE html>
<html>
<head>
  <title>Profile: <?php echo $table; ?></title>
  <link rel="stylesheet" href="EAstyles.css">
</head>
<body>
  <form method="post" enctype="multipart/form-data">
    <button type="submit" name="home" class="homebutton">EDUCATION<br>ASSISTANT</button><br>
    <options_left>
    <success>My Information:</success><br>  <?php
    $sql="select * from $table where username='$cuser'";
    $execute=$conn->query($sql);
    while($q=mysqli_fetch_assoc($execute))
    { ?>
      <center><p class="focus"><?php echo $q['name']; ?></p></center>  <?php
      echo $q['email'],"<br>";
      echo $q['phone'],"<br>";
      echo $q['institute'],"<br>";
      echo $q['department'],"<br>";
      echo $q['address'],"<br>";
    } ?>
    <center><button type="submit" name="changeinfo">Update Information</button></center>
      <hr><hr>
      <center><button type="submit" name="logout" class="logout">SIGN out</button></center>
    </options_left>
    <options_right>
      <success>Connections:</success><br>
      <button type="submit" name="connc">Connected Contacts</button><br>
      <button type="submit" name="connr">Connection Requests</button><br>
    <hr><hr>
      <center><button type="submit" name="goback">Go Back</button></center>
    </options_right>
    <div class="sticky">
      <center><button type="submit" name="profile" class="focus">Welcome, Mr. <?php echo $_SESSION['username'];?></button></center>
    </div>
    <div class="feed">
      <div class="sticky">
          <span><button type="submit" name="mypost" class="profilemenu">MY POSTS</button>
          <button type="submit" name="ntfy" class="profilemenu">MY TEAMS</button></span>
        </div>
      <?php
        if(!isset($_SESSION['username']))
        {
          header('Location:EAlogin.php');
        }
        else
        {
          if(isset($_POST['logout']))
          {
            session_destroy();
            header('Location:EAlogin.php');
          }
          elseif(isset($_POST['goback']))
          {
            header('Location:EAstuindex.php');
          }
          elseif(isset($_POST['ntfy']))
          {
            notifications($a_no);
          }
          
          elseif(isset($_POST['sendfrom']))
          {
            $suser=$_POST['sendfrom'];
            $_SESSION['sendfrom']=$suser;
            header('Location:EAview.php');
          }
          elseif(!empty($_POST['ryesdone']))
          {
            $accepted=$_POST['ryesdone'];
            $sql9="delete from connectionreq where conn_no='$accepted'";
            $execute9=$conn->query($sql9);
          }
          elseif(isset($_POST['ryes']))
          {
            $accept=$_POST['ryes'];
            $friend=$_POST['sender'];
            $sql3="insert into eaconnection (username, friend, conn_id) values ('$cuser', '$friend', '$accept')";
            $execute3=$conn->query($sql3);  ?>
            <input type="hidden" name="ryesdone" value="<?php echo $accept; ?>">  <?php
          }
          elseif(isset($_POST['rno']))
          {
            $reject=$_POST['rno'];
            $sql4="delete from connectionreq where conn_no='$reject'";
            $execute4=$conn->query($sql4);
          }
          elseif(isset($_POST['connr']))
          {
            $sql2="select * from connectionreq where sendto='$cuser'";
            $execute2=$conn->query($sql2);
            if($execute2->num_rows>0)
            {
              echo "<center>To confirm connection request select ACCEPT.</center><hr>";
              while($q2=mysqli_fetch_assoc($execute2))
              { ?>
                <button type="submit" name="sendfrom" value="<?php echo $q2['sendby']; ?>" class="user"><?php echo $q2['sendby']; ?></button> has sent request to connect.<br>  <input type="hidden" name="sender" value="<?php echo $q2['sendby']; ?>">
                <button type="submit" name="ryes" value="<?php echo $q2['conn_no']; ?>" class="login">ACCEPT</button>
                <button type="submit" name="rno" value="<?php echo $q2['conn_no']; ?>" class="logout">REJECT</button>  <?php
              }
            }
            else
            {
              echo "No connection request found!";
            }
          }
          elseif(isset($_POST['frnd']))
          {
            $frnd=$_POST['frnd'];
            $_SESSION['friend']=$frnd;
            header('Location:EAview.php');
          }
          elseif(isset($_POST['connc']))
          {
            $sql8="select * from eaconnection where username='$cuser'";
            $execute8=$conn->query($sql8);
            if($execute8->num_rows>0)
            {
              while($q8=mysqli_fetch_assoc($execute8))
              { ?>
                <button type="submit" name="frnd" class="user"><?php echo $q8['friend']; ?></button>
                <button type="submit" name="chat" class="small" value="<?php echo $q8['conn_id']; ?>">CHAT</button><hr> <?php
              }
            }
            else
            {
              echo "You have not made any connection yet!";
            }
          }
          elseif(isset($_POST['cyes']))
          {
            $a_no=$_POST['cyes'];
            $a=$_POST['eart'];
            if(!empty($_POST['efil']))
            {
              $f=$_POST['efil'];
              $sql5="update eapost set article='$a', file='$f' where a_no = '$a_no'";
              $execute5=$conn->query($sql5);
              echo "<center><warning>Changes Confirmed!</warning><center>";
            }
            else
            {
              $sql6="update eapost set article='$a' where a_no = '$a_no'";
              $execute6=$conn->query($sql6);
              echo "<center><warning>Changes Confirmed!</warning><center>";
            }
          }
          elseif(isset($_POST['cno']))
          {
            header('Location:EAprofile.php');
          }
          elseif(isset($_POST['editpost']))
          {
            $a_no=$_POST['editpost'];
            $a=$_POST['earticle'];
            if(!empty($_POST['upefile']))
            {
              $f=$_POST['upefile']; ?>
              <input type="hidden" name="efil" value="<?php echo $f; ?>"> <?php
            } ?>
            <center><warning>Confirm Changes?</warning><center>
            <center>
              <input type="hidden" name="eart" value="<?php echo $a; ?>">
              <button type="submit" name="cyes" class="logout" value="<?php echo $a_no; ?>">YES</button>
              <button type="submit" name="cno" class="login">NO</button> 
            </center> <?php
          }
          elseif(isset($_POST['dyes']))
          {
            $a_no=$_POST['dyes'];
            $sql7="delete from eapost where a_no = '$a_no'";
            $execute7=$conn->query($sql7);
            echo "<center><warning>Post Deleted!</warning><center>";
          }
          elseif(isset($_POST['dno']))
          {
            header('Location:EAprofile.php');
          }
          elseif(isset($_POST['deletepost']))
          { 
            $a_no=$_POST['deletepost'];
            echo "<center><warning>Are you sure? The post will be lost permanently!</warning><center>"; ?>
            <center>
              <button type="submit" name="dyes" class="logout" value="<?php echo $a_no; ?>">YES</button>
              <button type="submit" name="dno" class="login">NO</button> 
            </center> <?php
          }
          elseif(isset($_POST['managepost']))
          {
            $a_no=$_POST['managepost'];
            $sqlpost1="select * from eapost where a_no = '$a_no'";
            $executepost1=$conn->query($sqlpost1);
            while($qpost1=mysqli_fetch_assoc($executepost1))
            { ?>
              <center>Update or delete your post:</center>
              <hr>
            <table>
              <tr>
                <th class="focus">Post</th>
                <th class="focus">Date</th>
              </tr>
              <tr>
                <td class="limited_text"><textarea name="earticle" class="intext" cols="50" rows="4"><?php echo $qpost1['article'];?></textarea></td>
                <td class="time"><?php calculateTimeDifference($qpost1['date']);?></td>
              </tr>  <?php
              if(!empty($qpost1['file']))
              { ?>
              <tr>
                <td><?php echo $qpost1['file'];?></td>
              </tr> <?php
              } ?>
              <tr>
                <td><input type="file" name="upefile" class="intext"></td>
              </tr>
            </table>  <?php
            } ?>
            <center>
            <button type="submit" name="editpost" value="<?php echo $a_no; ?>">Edit Post</button>
            <button type="submit" name="deletepost" class="place" value="<?php echo $a_no; ?>">Delete Post</button><hr>
            <button type="submit" name="back">Back</button> 
            </center> <?php
          }
          elseif(isset($_POST['viewpost']))
          {
            $a_no=$_POST['viewpost'];
            $_SESSION['a_no']=$a_no;
            header('Location:EAposts.php');
          }
          elseif(isset($_POST['mypost']))
          {
            $sqlpost="select * from eapost where user = '$cuser' order by date desc";
            $executepost=$conn->query($sqlpost);
            if($executepost->num_rows>0)
            {
              while($qpost=mysqli_fetch_assoc($executepost))
              { ?>
                <hr>
              <table>
                <tr>
                  <th class="focus">Post</th>
                  <th class="focus">Date</th>
                </tr>
                <tr>
                  <td class="limited_text"><?php echo $qpost['article'];?></td>
                  <td class="time"><?php calculateTimeDifference($qpost['date']);?></td>
                </tr>  <?php
                if(!empty($qpost['file']))
                { ?>
                <tr>
                  <td><?php echo $qpost['file'];?></td>
                  <td><button type="submit" name="download" class="small">Download</button></td>
                </tr> <?php
                } ?>
              </table>
                <button type="submit" name="managepost" value="<?php echo $qpost['a_no']; ?>">Manage Post</button>
                <button type="submit" name="viewpost" class="place" value="<?php echo $qpost['a_no']; ?>">View Comments</button>
              <hr>  <?php
              }
              if(isset($_POST['download']))
              {
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="' . $qpost['file'] . '"');
              }
            }
            else
            {
              echo "<center>You have not posted anything...</center>";
            }
          }
          else
          { ?>
            <center>Write here to POST:<br>
            <input type="hidden" name="status" value="0">
            <textarea name="article" class="intext" cols="80" rows="4"></textarea><br>
            <input type="file" name="upfile" class="intext">
            <center><button type="submit" name="write">POST</button></center></center> <?php
            if(isset($_POST['write']))
            {
              if(!empty($_POST['article']))
              {
                $post=new EApost($_POST['status'],$_POST['article'],$_POST['upfile']);
                $post->insertPost($_SESSION['username']);
                header('Location:EAprofile.php');
              }
              else
              {
                echo "Write something to post!";
              }
            }
            else
            {
              echo "<center><note>**This is a trail run on this platfrom**<br>***©AIUB::WebTechnologies::Section[B]::Group5- All Right Researved***</note></center>";
            }
          }
        }
      ?>
      </div>
  </form>
</body>
</html>