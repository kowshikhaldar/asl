-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2023 at 10:52 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eduassist`
--

-- --------------------------------------------------------

--
-- Table structure for table `connectionreq`
--

CREATE TABLE `connectionreq` (
  `sendby` varchar(20) NOT NULL,
  `sendto` varchar(20) NOT NULL,
  `conn_no` mediumint(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eachat`
--

CREATE TABLE `eachat` (
  `chat_id` mediumint(15) NOT NULL,
  `chat` varchar(1000) NOT NULL,
  `file` mediumblob NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `eacomment`
--

CREATE TABLE `eacomment` (
  `a_no` bigint(15) NOT NULL,
  `comment` mediumtext NOT NULL,
  `cuser` varchar(20) NOT NULL,
  `cdate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `c_no` bigint(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eacomment`
--

INSERT INTO `eacomment` (`a_no`, `comment`, `cuser`, `cdate`, `c_no`) VALUES
(83, 'comment test 1', 'sahadul', '2023-11-05 03:27:32', 74),
(83, 'comment test2', 'sahadul', '2023-11-05 04:27:34', 76),
(83, 'Testing with another user', 'salam', '2023-11-05 05:27:42', 77),
(84, 'Hello... Nice to meet you too...', 'sahadul', '2023-11-05 05:28:49', 78),
(85, 'ami sadman', 'sahadul', '2023-11-05 12:14:57', 79),
(87, '', 'sahadul', '2023-11-05 20:53:18', 80),
(90, 'hello testing comments...', 'sahadul', '2023-11-07 17:10:02', 81),
(91, 'nice job mate!', 'siddik', '2023-11-09 05:46:21', 82);

-- --------------------------------------------------------

--
-- Table structure for table `eaconnection`
--

CREATE TABLE `eaconnection` (
  `username` varchar(20) NOT NULL,
  `friend` varchar(20) NOT NULL,
  `conn_id` mediumint(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eaconnection`
--

INSERT INTO `eaconnection` (`username`, `friend`, `conn_id`) VALUES
('sahadul', 'salam', 3),
('sahadul', 'siddik', 4),
('sahadul', 'osman', 5);

-- --------------------------------------------------------

--
-- Table structure for table `eapost`
--

CREATE TABLE `eapost` (
  `user` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL,
  `article` mediumtext NOT NULL,
  `file` mediumblob NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `a_no` bigint(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `eapost`
--

INSERT INTO `eapost` (`user`, `status`, `article`, `file`, `date`, `a_no`) VALUES
('sahadul', 0, 'test 1.... only text', '', '2023-11-03 07:40:31', 66),
('sahadul', 0, 'test 1.... only text', '', '2023-11-03 07:40:38', 67),
('sahadul', 0, 'test 1.... only text', '', '2023-11-03 07:40:49', 68),
('sahadul', 0, 'test 2... repeation fixed', '', '2023-11-03 07:43:06', 69),
('sahadul', 0, 'test 2... repeation fixed', '', '2023-11-03 07:43:14', 70),
('sahadul', 0, 'test 3...', '', '2023-11-03 07:51:42', 71),
('sahadul', 0, 'test 4....', '', '2023-11-03 07:52:03', 72),
('sahadul', 0, 'test 5..', '', '2023-11-03 07:52:56', 73),
('sahadul', 0, 'test 5..', '', '2023-11-03 07:53:00', 74),
('sahadul', 0, 'test 6....', '', '2023-11-03 07:54:15', 75),
('sahadul', 0, 'final text test....', '', '2023-11-03 07:55:01', 77),
('sahadul', 0, 'Posting text is successful.......', '', '2023-11-03 07:55:35', 78),
('sahadul', 0, 'testing file... test 1...', 0x4d4145535f4d49445f41737369676e6d656e745f322e706466, '2023-11-03 07:56:12', 79),
('sahadul', 0, 'download fail... after posting a file..', '', '2023-11-03 07:57:13', 80),
('sahadul', 0, 'download success... but not supported', '', '2023-11-03 07:58:32', 81),
('sahadul', 0, 'Posting test again', '', '2023-11-04 01:27:12', 82),
('sahadul', 0, 'testing post', '', '2023-11-04 03:02:39', 83),
('salam', 0, 'Hi I am salam... nice to meet you all....', '', '2023-11-05 05:27:10', 84),
('sahadul', 0, 'Limitations and Possible Future Improvements:\r\nImplementation of all the features of EA can be challenging based on the limitations of the current study. For example, the donation feature, which is one of the most prominent features requires transaction verifications via authentication, and collaboration feature requires encryptions with high security measures, download application version requires software development process. After implementation, EA must require uninterrupted servers with a vast networking database.\r\nFor future improvements, a few additional features can be introduced, for example, free online courses, events, competitions, communities, skilled based certification, application version of EA for all known operating systems.\r\n', '', '2023-11-05 14:50:39', 86),
('sahadul', 0, 'posting to see that the time function works....', '', '2023-11-05 20:27:20', 87),
('sahadul', 0, 'posting from profile page !!!edit fixed!!! error handled! (bug fix)', '', '2023-11-09 04:57:03', 91);

-- --------------------------------------------------------

--
-- Table structure for table `logininfo`
--

CREATE TABLE `logininfo` (
  `username` varchar(10) NOT NULL DEFAULT 'not null',
  `password` varchar(30) NOT NULL DEFAULT 'not null',
  `usertype` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `logininfo`
--

INSERT INTO `logininfo` (`username`, `password`, `usertype`) VALUES
('nyem', '1122', 'teacher'),
('osman', '1212', 'student'),
('sac', '12345', 'teacher'),
('sahadul', '1234', 'student'),
('salam', '123', 'teacher'),
('siddik', '1313', 'student');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `name` varchar(30) NOT NULL,
  `age` int(3) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phone` varchar(14) NOT NULL,
  `institute` varchar(50) NOT NULL,
  `department` varchar(50) NOT NULL,
  `address` varchar(250) NOT NULL,
  `username` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`name`, `age`, `email`, `phone`, `institute`, `department`, `address`, `username`) VALUES
('siddik', 24, 'siddik@gmail.com', '01721212121', 'AIUB', 'CSE', 'Dhaka', 'siddik'),
('osman', 55, 'osman@gmail.com', '01757193697', 'AIUB', 'CSE', 'dhaka', 'osman'),
('arham', 20, 'arham@gmail.com', '01789456123', 'AIUB', 'CSE', 'dhaka', 'arham'),
('Md Sahadul Haque', 25, 'sahadul80@gmail.com', '01866820045', 'AIUB', 'CSE', 'Nikunja-2', 'sahadul');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `name` varchar(30) NOT NULL,
  `age` int(3) NOT NULL,
  `email` varchar(40) NOT NULL,
  `phone` int(14) NOT NULL,
  `institute` varchar(50) NOT NULL,
  `designation` varchar(50) NOT NULL,
  `faculty` varchar(30) NOT NULL,
  `department` varchar(20) NOT NULL,
  `address` varchar(250) NOT NULL,
  `username` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`name`, `age`, `email`, `phone`, `institute`, `designation`, `faculty`, `department`, `address`, `username`) VALUES
('abdus salam', 30, 'salam@gmail.com', 147896325, 'aiub', 'assistant prof.', 'FST', 'CSE', 'dhaka', 'salam'),
('sa', 22, 'sa@gmail.com', 1711877508, 'aiub', 'lecturer', 'fst', 'cse', 'dhaka', 'sac'),
('nyem', 27, 'nyem@gmail.com', 2147483647, 'aiub', 'lecturer', 'fst', 'cse', 'dhaka', 'nyem');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `connectionreq`
--
ALTER TABLE `connectionreq`
  ADD PRIMARY KEY (`conn_no`);

--
-- Indexes for table `eachat`
--
ALTER TABLE `eachat`
  ADD PRIMARY KEY (`chat_id`);

--
-- Indexes for table `eacomment`
--
ALTER TABLE `eacomment`
  ADD PRIMARY KEY (`c_no`);

--
-- Indexes for table `eaconnection`
--
ALTER TABLE `eaconnection`
  ADD PRIMARY KEY (`conn_id`);

--
-- Indexes for table `eapost`
--
ALTER TABLE `eapost`
  ADD PRIMARY KEY (`a_no`);

--
-- Indexes for table `logininfo`
--
ALTER TABLE `logininfo`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`phone`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `connectionreq`
--
ALTER TABLE `connectionreq`
  MODIFY `conn_no` mediumint(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `eacomment`
--
ALTER TABLE `eacomment`
  MODIFY `c_no` bigint(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `eapost`
--
ALTER TABLE `eapost`
  MODIFY `a_no` bigint(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=92;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
