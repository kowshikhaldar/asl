<!DOCTYPE html>
<html>
<head>
	<title>Registration Form</title>
	<link rel="stylesheet" href="EAstyles.css"></head>
<body>
	<form method="post">
	<button type="submit" name="home" class="homebutton">EDUCATION<br>ASSISTANT</button><br>
	<center>
		<fieldset>
		<legend class="focus">Welcome to Education Assistant!</legend>
		<button type="submit" name="sreg" class="submenu">Register as A STUDENT!</button><hr>
		<button type="submit" name="treg" class="submenu">Register as A TEACHER!</button><hr>
		<button type="submit" name="apply" class="submenu">APPLY as a REVIEW board member!</button><br> 
		<note>NOTE: You must have completed doctorate in your respected field. Provide your RESUME along with the research papers (as a primary article writer).</note><hr>
		To LOGIN<button type="submit" name="login" class="login">Click HERE!</button>
		</fieldset>
	</center>
	</form>
</body>
</html>

<?php
	if(isset($_POST['login']))
	{
		header("Location:EAlogin.php");
	}
	elseif(isset($_POST['treg']))
	{
		header("Location:EAteacherreg.php");
	}
	elseif(isset($_POST['sreg']))
	{
		header("Location:EAstudentreg.php");
	}
	elseif(isset($_POST['apply']))
    {
        header('Location:EAapply.php');
    }
	elseif(isset($_POST['home']))
	{
		header("Location:EAhome.php");
	}
	else
	{
		echo "<center><note>**This is a trail run on this platfrom**<br>***©AIUB::WebTechnologies::Section[B]::Group5- All Right Researved***</note></center>";
	}
?>