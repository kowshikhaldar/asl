<?php
include 'EAusers.php';
include 'EAstudents.php';
include 'EAteachers.php';
include 'EA.php';

function calculateTimeDifference($timestamp) 
{
    date_default_timezone_set('Asia/Dhaka');
    // Convert the timestamp to a DateTime object
    $postDateTime = DateTime::createFromFormat('Y-m-d H:i:s', $timestamp);

    // Get the current DateTime
    $currentDateTime = new DateTime();

    // Calculate the time difference
    $timeDifference = $currentDateTime->diff($postDateTime);

    // Format and display the time difference
    echo "Posted ";
    if ($timeDifference->y > 0) {
        echo $timeDifference->y . " year" . ($timeDifference->y > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->m > 0) {
        echo $timeDifference->m . " month" . ($timeDifference->m > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->d > 0) {
        echo $timeDifference->d . " day" . ($timeDifference->d > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->h > 0) {
        echo $timeDifference->h . " hour" . ($timeDifference->h > 1 ? "s" : "") . " ago";
    } elseif ($timeDifference->i > 0) {
        echo $timeDifference->i . " minute" . ($timeDifference->i > 1 ? "s" : "") . " ago";
    } else {
        echo "a few seconds ago";
    }
}

 function editSelectedpost($a_no)
 {
    $servername="localhost";
    $user="root";
    $pass="";
    $dbase="eduassist";
    $conn=new mysqli($servername,$user,$pass,$dbase);
    if (!$conn)
    { 
      die('Connection FAILED! Error found: '.mysqli_error()); 
    }
    else
    {
      $sqlpost="select * from eapost where a_no = '$a_no'";
      $execute=$conn->query($sqlpost);
      if($execute->num_rows>0)
      {
        while($q=mysqli_fetch_assoc($execute))
        { ?>
          <table>
          <tr>
            <td rowspan="2"><textarea name="article" value="<?php echo $q['article'];?>" class="intext" cols="36" rows="6"></textarea></td>
            <td class="time"><?php calculateTimeDifference($q['date']);?></td>
          </tr>  <?php
          if(!empty($q['file']))
          { ?>
          <tr>
            <td>Select to replace the file: <?php echo $q['file'];?></td>
            <td><input type="file" name="upfile" class="intext"></td> <?php
          }
          else
          { ?>
            <input type="file" name="upfile" class="intext">    <?php  
          } ?>
          </tr>
          <tr>
            <td><button type="submit" name="confirmedit">Edit Post</button></td>
            <td><button type="submit" name="delete" class="logout">Delete Post</button></td>
          </tr>
          </table>
          <hr>
            <?php
        }
      }
      else
      {
        echo "<center>No Post Found!</center>";
      }
    }
  }

  function editPost($a_no,$article,$file)
  {
    $servername="localhost";
    $user="root";
    $pass="";
    $dbase="eduassist";
    $conn=new mysqli($servername,$user,$pass,$dbase);
    if (!$conn)
    { 
      die('Connection FAILED! Error found: '.mysqli_error()); 
    }
    else
    {
      $sqlpost="update eapost set article = '$article', file = '$file' where a_no = '$a_ano'";
      $execute=$conn->query($sqlpost);
      if(!$execute)
      {
        echo "<center>Unable to Update!</center>";
      }
      else
      {
        editSelectedpost($a_no);
        echo "<center>Successfully Updated!</center>";
      }
    }
  }

  function deletePost($a_no)
  {
    $servername="localhost";
    $user="root";
    $pass="";
    $dbase="eduassist";
    $conn=new mysqli($servername,$user,$pass,$dbase);
    if (!$conn)
    { 
      die('Connection FAILED! Error found: '.mysqli_error()); 
    }
    else
    {
      $sqlpost="delete from eapost where a_no = '$a_no'";
      $execute=$conn->query($sqlpost);
      if(!$execute)
      {
        echo "<center>Unable to Delete!</center>";
      }
      else
      {
        editSelectedpost($a_no);
        echo "<center>Post has been Deleted!</center>";
      }
    }
  }

<!DOCTYPE html>
<html>
<head>
	<title>Manage Post</title>
	<link rel="stylesheet" href="EAstyles.css">
</head>
<body>
	<form method="post">
      <button type="submit" name="home" class="homebutton">EDUCATION<br>ASSISTANT</button><br>
      <fieldset>
      	<legend class="focus">Manage Post</legend>
<?php
include 'EA.php';

	session_start();
	if(!isset($_SESSION['a_no'])) 
    {
    	header('Location:EAprofile.php');
    }
    else
    {
    	$a_no=$_SESSION['a_no'];
        $cuser=$_SESSION['username'];
       	if(isset($_POST['back']))
        {
            header('Location:EAprofile.php');
        }
        elseif(isset($_POST['confirmedit']))
        {
          echo "<center><warning>Do you really want to change the current post?</warning></center>";  ?>
          <center><button type="submit" name="y" class="logout">YES</button>
          <shift-right><button type="submit" name="n" class="login">NO</button></shift-right></center> <?php
          if(isset($_POST['y']))
          {
            editPost($a_no);
          }
          else
          {
            editSelectedpost($a_no);
          }
        }
        elseif(isset($_POST['delete']))
        {
          echo "<center><warning>Do you really want to DELETE the post?</warning></center>";  ?>
          <center><button type="submit" name="yes" class="logout">YES</button>
          <shift-right><button type="submit" name="no" class="login">NO</button></shift-right></center> <?php
          if(isset($_POST['yes']))
          {
            deletePost($a_no);
          }
          else
          {
            editSelectedpost($a_no);
          }
        }
        elseif(isset($_POST['back']))
        {
          header('Location:EAprofile.php');
        }
        else
        {
          echo "<center>**Select the desire field to edit**</center>";
        }
    }
		</fieldset>
      <center><button type="submit" name="back">BACK</button></center>
  	</form>
</body>
</html>